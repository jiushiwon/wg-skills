<script setup lang="ts">
import { computed } from 'vue';
import { useUserStore } from '@/stores/modules/user';

const userStore = useUserStore();
const nickname = computed(() => userStore.nickname || '未登录');

function handleLogin() {
  // 调用登录逻辑
  uni.showToast({ title: '登录功能待实现', icon: 'none' });
}
</script>

<template>
  <view class="page profile-page">
    <view class="profile-page__user">
      <image
        class="profile-page__avatar"
        src="/static/avatar-placeholder.png"
        mode="aspectFill"
      />
      <text class="profile-page__nickname">{{ nickname }}</text>
    </view>

    <view class="profile-page__menu">
      <view class="profile-page__item" @tap="handleLogin">
        <text class="profile-page__item-text">登录 / 退出</text>
        <text class="profile-page__item-arrow">></text>
      </view>
      <view class="profile-page__item">
        <text class="profile-page__item-text">设置</text>
        <text class="profile-page__item-arrow">></text>
      </view>
    </view>
  </view>
</template>

<style lang="scss" scoped>
.profile-page {
  min-height: 100vh;
  background: $color-bg-secondary;

  &__user {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: $spacing-xl 0;
    background: $color-bg-primary;
    margin-bottom: $spacing-md;
  }

  &__avatar {
    width: 120rpx;
    height: 120rpx;
    border-radius: $radius-full;
    background: $color-bg-tertiary;
  }

  &__nickname {
    margin-top: $spacing-sm;
    font-size: $font-title;
    color: $color-text-primary;
  }

  &__menu {
    background: $color-bg-primary;
  }

  &__item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: $spacing-md;
    border-bottom: 1rpx solid $color-border-light;

    &:active {
      background: $color-bg-secondary;
    }
  }

  &__item-text {
    font-size: $font-body;
    color: $color-text-primary;
  }

  &__item-arrow {
    font-size: $font-body;
    color: $color-text-tertiary;
  }
}
</style>
