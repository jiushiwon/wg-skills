export enum TabBarKey {
  HOME = 'home',
  PROFILE = 'profile',
}

export const TAB_BAR_TEXT: Record<TabBarKey, string> = {
  [TabBarKey.HOME]: '首页',
  [TabBarKey.PROFILE]: '我的',
};
