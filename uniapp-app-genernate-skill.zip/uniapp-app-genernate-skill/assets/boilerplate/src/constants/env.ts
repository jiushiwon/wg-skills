// 项目环境变量统一入口
export const PEXELS_API_KEY = import.meta.env.VITE_PEXELS_API_KEY || '';

if (!PEXELS_API_KEY) {
  console.warn('[env] PEXELS_API_KEY is not configured');
}
