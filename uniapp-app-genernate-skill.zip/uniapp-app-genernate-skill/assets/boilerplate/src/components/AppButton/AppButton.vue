<script setup lang="ts">
withDefaults(
  defineProps<{
    type?: 'primary' | 'secondary' | 'ghost';
    size?: 'small' | 'medium' | 'large';
    disabled?: boolean;
  }>(),
  {
    type: 'primary',
    size: 'medium',
    disabled: false,
  },
);

const emit = defineEmits<{
  (e: 'click', event: MouseEvent): void;
}>();

function handleClick(event: MouseEvent) {
  emit('click', event);
}
</script>

<template>
  <button
    class="app-button"
    :class="[`app-button--${type}`, `app-button--${size}`, { 'app-button--disabled': disabled }]"
    :disabled="disabled"
    @click="handleClick"
  >
    <slot />
  </button>
</template>

<style lang="scss" scoped>
.app-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: $radius-md;
  font-size: $font-body;
  font-weight: 500;
  transition: opacity 0.2s;

  &::after {
    display: none;
  }

  &--primary {
    background: $color-primary;
    color: $color-bg-primary;
  }

  &--secondary {
    background: $color-primary-light;
    color: $color-primary-dark;
  }

  &--ghost {
    background: transparent;
    color: $color-primary;
    border: 1rpx solid $color-primary;
  }

  &--small {
    padding: $spacing-xs $spacing-sm;
  }

  &--medium {
    padding: $spacing-sm $spacing-md;
  }

  &--large {
    padding: $spacing-md $spacing-lg;
    font-size: $font-title;
  }

  &--disabled {
    opacity: 0.5;
  }

  &:active {
    opacity: 0.8;
  }
}
</style>
