import { isApp, isH5, isMpWeixin } from './platform';

export interface ShareOptions {
  title?: string;
  path?: string;
  imageUrl?: string;
  query?: string;
  url?: string;
}

/**
 * 平台化分享
 * - 微信小程序：在页面 onShareAppMessage 中返回配置
 * - H5：调用 Web Share API 或复制链接
 * - App：调用系统分享或原生 SDK
 */
export function platformShare(options: ShareOptions): void {
  if (isMpWeixin()) {
    // 微信小程序需在页面 onShareAppMessage 中返回配置
    console.log('[share] wechat', options);
    return;
  }

  if (isH5()) {
    if (navigator.share) {
      navigator.share({
        title: options.title || '',
        url: options.url || window.location.href,
      }).catch(() => {
        // 用户取消
      });
    } else {
      uni.showToast({ title: '请手动复制链接分享', icon: 'none' });
    }
    return;
  }

  if (isApp()) {
    uni.shareWithSystem({
      type: 'text',
      summary: options.title,
      href: options.url || options.path,
    });
    return;
  }
}
