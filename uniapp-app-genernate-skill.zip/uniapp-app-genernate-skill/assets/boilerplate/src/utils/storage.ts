const PREFIX = 'uniapp_';

export const storage = {
  get(key: string): any {
    const value = uni.getStorageSync(`${PREFIX}${key}`);
    return value;
  },

  set(key: string, value: any): void {
    uni.setStorageSync(`${PREFIX}${key}`, value);
  },

  remove(key: string): void {
    uni.removeStorageSync(`${PREFIX}${key}`);
  },

  clear(): void {
    uni.clearStorageSync();
  },
};
