import { isApp, isH5, isMpWeixin } from './platform';

export interface AuthResult {
  token: string;
  openid?: string;
  nickname?: string;
  avatar?: string;
}

/**
 * 平台化登录
 * - 微信小程序：uni.login 获取 code，再发给后端换 token
 * - H5：提示使用账号或第三方 OAuth（示例）
 * - App：根据配置选择原生登录或跳转
 */
export async function platformLogin(): Promise<AuthResult | null> {
  if (isMpWeixin()) {
    return new Promise<AuthResult | null>((resolve) => {
      uni.login({
        provider: 'weixin',
        success: (res) => {
          if (res.code) {
            // 实际项目中发送到后端换取 token
            resolve({ token: res.code, openid: '' });
          } else {
            resolve(null);
          }
        },
        fail: () => resolve(null),
      });
    });
  }

  if (isH5()) {
    // H5 登录逻辑：示例为弹窗提示，实际项目接入 OAuth/账号密码
    uni.showToast({ title: 'H5 请使用账号或第三方登录', icon: 'none' });
    return null;
  }

  if (isApp()) {
    // App 登录逻辑：示例为 uni.login，实际可能集成微信 SDK 或手机号一键登录
    return new Promise<AuthResult | null>((resolve) => {
      uni.login({
        provider: 'weixin',
        success: (res) => {
          resolve({ token: res.code || '', openid: '' });
        },
        fail: () => resolve(null),
      });
    });
  }

  return null;
}

/**
 * 获取用户信息
 * 微信小程序需使用 button open-type="chooseAvatar"
 */
export async function getUserProfile(): Promise<{ nickname: string; avatar: string } | null> {
  if (isMpWeixin()) {
    // 小程序新版用户信息获取需用户主动触发
    return null;
  }

  if (isH5()) {
    // H5 从登录态中读取
    return null;
  }

  return null;
}
