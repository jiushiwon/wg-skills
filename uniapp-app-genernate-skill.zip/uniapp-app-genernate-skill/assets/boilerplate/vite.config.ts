import { defineConfig } from 'vite';
import uni from '@dcloudio/vite-plugin-uni';

export default defineConfig({
  plugins: [uni()],
  define: {
    'import.meta.env.VITE_PEXELS_API_KEY': JSON.stringify(process.env.PEXELS_API_KEY || ''),
    'import.meta.env.VITE_BASE_URL': JSON.stringify(process.env.VITE_BASE_URL || ''),
    'import.meta.env.VITE_H5_BASE_URL': JSON.stringify(process.env.VITE_H5_BASE_URL || ''),
    'import.meta.env.VITE_APP_BASE_URL': JSON.stringify(process.env.VITE_APP_BASE_URL || ''),
  },
  resolve: {
    alias: {
      '@': '/src',
    },
  },
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: '@import "@/styles/variables.scss";',
      },
    },
  },
});
